from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

Share = InlineKeyboardMarkup(
    inline_keyboard=[
    [
        InlineKeyboardButton(text="Bizning kanal", url = "https://t.me/itduzb_grantlar_chetda_xorijda"),
        InlineKeyboardButton(text="Botni ulashish", url="https://t.me/share/url?url=https%3A//t.me/konspektor_bot"),
    ],


])