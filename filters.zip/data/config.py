BOT_TOKEN = '5055641557:AAEyI2Yc1si40c1dUgcdv8KCbIyggEyhdms'
ADMINS = [971143551]

CHANNELS = ['-1001559756714']

btns = {
    "accept": "✅ A'zo bo'ldim",
    "back": "Ortga qaytish",
}

texts = {
    "text_to_start": f"<b>Assalomu alaykum! Botimizdan foydalanish uchun quyidagi kanallarga obuna bo'lishingiz kerak</b>",
    "main_menu": "Iltimos quyidagi menulardan birini tanlang!",
    "notaccepted": "❌<b> Quyidagi kanallarga a'zo bo'lmadingiz</b>, iltimos botdan foydalanish uchun kanalga a'zo bo'ling!",
    "accepted": "*Salom men orqali osongina konspekt qila olasiz shunchaki menga matn yuboring*",
}